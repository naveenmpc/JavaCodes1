package extentreportdemos;

public class SetupExtent {

}
