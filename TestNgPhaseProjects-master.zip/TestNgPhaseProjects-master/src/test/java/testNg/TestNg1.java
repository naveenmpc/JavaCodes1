package testNg;

import org.testng.annotations.Test;

public class TestNg1 {
	
	@Test
	public void method1()
	{
	}
	
	}


