package com.app.junit;

public class JavaOperations {

}
