package com.app.junit;

import java.util.concurrent.TimeUnit;

public class Assertions {

	public static Object assertTrue(boolean b) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void assertEquals(Class<String> class1, Class<?> targetType, String string) {
		// TODO Auto-generated method stub
		
	}

	public static void assertNotNull(TimeUnit valueOf) {
		// TODO Auto-generated method stub
		
	}

	public static void assertNotNull(String name) {
		// TODO Auto-generated method stub
		
	}

}
