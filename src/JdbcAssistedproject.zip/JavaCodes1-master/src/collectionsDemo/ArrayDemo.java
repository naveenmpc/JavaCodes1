package collectionsDemo;

public class ArrayDemo {

}
