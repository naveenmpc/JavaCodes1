package lessonendproject;

public class Shape {

	public static void main(String[] args) {	// TODO Auto-generated method stub
		  System.out.println("This shape does not have a specific area calculation method.");

	}

	public void displayArea() {
		// TODO Auto-generated method stub
		
	}

}
