package javaPrograms;

public class Forloop2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="LearningJava";
		int len=s1.length();
		
		for(int i=8;i<len;i++)
		{
			System.out.print(s1.charAt(i));
	}

}
}
