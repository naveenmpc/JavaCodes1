package javaPrograms;

public class StringMethodsDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Selenium ";
		String s2="Java";
		
		String s3=s1+s2;
		
		System.out.println("Concatinating string using + operator:" +s3);
		
		String s4=s1.concat(s2);
		
		System.out.println("concating the string using using method concat:" +s4);
		
	}

}
