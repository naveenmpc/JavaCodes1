package javaPrograms;

public class Dowhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i=1;
		
		do {
			System.out.println("Today is Wednesday");
			i++;
		}
		while(i>=7);
		System.out.println("out of loop");

	}
	
}
