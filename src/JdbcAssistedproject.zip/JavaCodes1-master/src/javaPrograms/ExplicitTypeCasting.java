package javaPrograms;

public class ExplicitTypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  double a=12.789;
  

     int b=(int)a;
  
  System.out.println(b);
	}

}
