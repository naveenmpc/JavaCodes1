$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"f896ba0a-27bb-481f-8428-d5b4ec697e62","feature":"Test the starHealth page on Chrome Browser","scenario":"Validate the Star Health Buy Now flow","start":1698160641731,"group":1,"content":"","tags":"","end":1698160838048,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});