package gradleDemo;

public class DemoTest {

}
